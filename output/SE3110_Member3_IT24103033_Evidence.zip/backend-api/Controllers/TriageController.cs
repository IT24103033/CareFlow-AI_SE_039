using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CareFlowAI.API.Data;
using CareFlowAI.API.Models;
using CareFlowAI.API.DTOs;
using CareFlowAI.API.Services;

namespace CareFlowAI.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TriageController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        private readonly PlanningAgentService _planningAgent;
        private readonly ISafetyAgent _safetyAgent;
        private readonly CloudinaryDotNet.Cloudinary? _cloudinary;
        private readonly CareFlowAI.Orchestrator.Agents.AppointmentActionAgent _appointmentAgent;

        public TriageController(
            ApplicationDbContext context,
            PlanningAgentService planningAgent,
            IServiceProvider serviceProvider,
            CareFlowAI.Orchestrator.Agents.AppointmentActionAgent appointmentAgent,
            ISafetyAgent? safetyAgent = null)
        {
            _context       = context;
            _planningAgent = planningAgent;
            _appointmentAgent = appointmentAgent;
            _safetyAgent   = safetyAgent ?? new PharmacyAiService();
            _cloudinary    = serviceProvider.GetService<CloudinaryDotNet.Cloudinary>();
        }

        // ────────────────────────────────────────────────────────────────────
        // POST api/triage
        // Flutter app calls this when a patient submits symptoms.
        // Saves the record, triggers the Planning Agent, and executes SafetyAgent validation.
        // ────────────────────────────────────────────────────────────────────
        [Authorize(Roles = "Patient,Doctor,Staff,Admin")]
        [HttpPost]
        public async Task<IActionResult> Submit([FromBody] CreateTriageRequestDto dto, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(dto.Symptoms) ||
                dto.Symptoms.Trim().Length < 20 || dto.Symptoms.Length > 4000 || dto.Duration?.Length > 200)
                return BadRequest("Provide symptoms between 20 and 4000 characters.");

            Guid patientId;
            if (User?.IsInRole("Patient") == true)
            {
                var patientClaim = User?.FindFirst("patient_id")?.Value;
                if (!Guid.TryParse(patientClaim, out var authPatientId))
                    return StatusCode(403, "Authenticated patient identity is missing or invalid.");

                if (dto.PatientId != Guid.Empty && dto.PatientId != authPatientId)
                    return StatusCode(403, "You cannot submit triage records on behalf of another patient.");

                patientId = authPatientId;
            }
            else
            {
                if (dto.PatientId == Guid.Empty)
                    return BadRequest("Provide a valid patient ID.");
                patientId = dto.PatientId;
            }

            // 1. Validate that the patient exists
            var patient = await _context.PatientProfiles.FindAsync(patientId);
            if (patient == null)
                return NotFound("Patient profile not found.");

            // 1.5. Immediate Safety/Emergency Check (Intercept before AI planning or queueing)
            var tempRecord = new TriageRecord { Symptoms = dto.Symptoms.Trim(), SeverityLevel = "Unassessed" };
            var safetyCheck = _safetyAgent.CheckEmergencyRules(tempRecord, null);
            bool isEmergency = false;
            try
            {
                var safetyDoc = JsonDocument.Parse(safetyCheck.OutputPayload);
                isEmergency = safetyDoc.RootElement.GetProperty("IsEmergency").GetBoolean();
            }
            catch { }

            if (isEmergency)
            {
                var emergencyRecord = new TriageRecord
                {
                    PatientId = patientId,
                    Symptoms = dto.Symptoms.Trim(),
                    AttachmentId = dto.AttachmentId,
                    TriageStatus = "InReview",
                    SeverityLevel = "Critical"
                };

                if (dto.AttachmentId.HasValue)
                {
                    var attachment = await _context.TriageAttachments.FindAsync(dto.AttachmentId.Value);
                    if (attachment != null && attachment.UploaderId == patientId && attachment.TriageRecordId == null)
                    {
                        attachment.TriageRecordId = emergencyRecord.Id;
                        emergencyRecord.Attachment = attachment;
                    }
                }

                var planObj = new
                {
                    SchemaVersion = 1,
                    UrgencyLevel = "Critical",
                    Rationale = "Stop. Your symptoms indicate a life-threatening emergency. Call 911 or go to the nearest emergency room immediately.",
                    SuggestedSpecialist = "General Practitioner",
                    RecommendedAction = "Call 911 or visit the ER immediately"
                };

                var emergencyAgentState = new AgentWorkflowState
                {
                    AgentName = "PlanningAgent",
                    AgentStatus = "Completed",
                    OutputPayload = System.Text.Json.JsonSerializer.Serialize(planObj)
                };

                _context.TriageRecords.Add(emergencyRecord);
                emergencyAgentState.TriageRecordId = emergencyRecord.Id;
                _context.AgentWorkflows.Add(emergencyAgentState);
                await _context.SaveChangesAsync(cancellationToken);

                return CreatedAtAction(nameof(GetById), new { id = emergencyRecord.Id }, MapToDto(emergencyRecord, emergencyAgentState, _cloudinary));
            }

            // 2. Save the triage record
            var record = new TriageRecord
            {
                PatientId    = patientId,
                Symptoms     = dto.Symptoms.Trim(),
                AttachmentId = dto.AttachmentId,
                TriageStatus = "Pending",
                SeverityLevel = "Unassessed"
            };

            if (dto.AttachmentId.HasValue)
            {
                var attachment = await _context.TriageAttachments.FindAsync(dto.AttachmentId.Value);
                if (attachment != null && attachment.UploaderId == patientId && attachment.TriageRecordId == null)
                {
                    attachment.TriageRecordId = record.Id;
                    record.Attachment = attachment;
                }
                else
                {
                    return BadRequest("Invalid attachment ID or unauthorized.");
                }
            }
            // Persist the record AND running workflow before any context/model call.
            var agentState = PlanningAgentService.CreateRunningState(record, dto.Duration);
            _context.TriageRecords.Add(record);
            _context.AgentWorkflows.Add(agentState);
            await _context.SaveChangesAsync(cancellationToken);

            await _planningAgent.RunAsync(record, agentState, cancellationToken);
            var plan = agentState.AgentStatus == "Completed" ? TriageReviewRules.ReadPlan(agentState.OutputPayload) : null;
            record.TriageStatus = plan == null ? "AssessmentFailed" : "InReview";
            record.SeverityLevel = plan?.UrgencyLevel ?? "Unassessed";

            // 3. Integrate Component C ActionAgent and Component D SafetyAgent
            if (plan != null)
            {
                await TriageOrchestrationHelper.ExecuteDownstreamActionsAsync(
                    record, plan, _context, _safetyAgent, _appointmentAgent);
            }

            record.UpdatedAt = DateTime.UtcNow;
            // Persist cancellation/failure even if the HTTP client disconnected. A process
            // crash still leaves a durable Running row for the future recovery worker.
            await _context.SaveChangesAsync(CancellationToken.None);

            return CreatedAtAction(nameof(GetById), new { id = record.Id }, MapToDto(record, agentState, _cloudinary));
        }

        [Authorize(Roles = "Patient,Doctor,Admin")]
        [HttpPost("upload-image")]
        public async Task<IActionResult> UploadImage(IFormFile image, [FromServices] CloudinaryDotNet.Cloudinary cloudinary, CancellationToken cancellationToken = default)
        {
            if (image == null) return BadRequest("No image provided (image parameter is null).");
            if (image.Length == 0) return BadRequest("Image provided but length is 0.");
            
            if (image.Length > 5 * 1024 * 1024) return BadRequest($"Image size ({image.Length} bytes) exceeds the 5MB limit.");

            var allowedTypes = new[] { "image/jpeg", "image/png", "image/webp", "application/octet-stream" };
            if (!allowedTypes.Contains(image.ContentType)) return BadRequest($"Invalid file type '{image.ContentType}'. Only JPEG, PNG, and WebP are allowed.");

            if (cloudinary == null) return StatusCode(500, "Cloudinary configuration is missing.");

            using var stream = image.OpenReadStream();
            var uploadParams = new CloudinaryDotNet.Actions.ImageUploadParams
            {
                File = new CloudinaryDotNet.FileDescription(image.FileName, stream),
                Folder = "triage-images",
                Type = "authenticated"
            };

            var uploadResult = await cloudinary.UploadAsync(uploadParams, cancellationToken);
            
            if (uploadResult.Error != null) return StatusCode(500, $"Image upload failed: {uploadResult.Error.Message}");

            Guid uploaderId = Guid.Empty;
            if (User?.IsInRole("Patient") == true)
            {
                var patientClaim = User?.FindFirst("patient_id")?.Value;
                Guid.TryParse(patientClaim, out uploaderId);
            }
            else
            {
                var doctorClaim = User?.FindFirst("doctor_id")?.Value;
                Guid.TryParse(doctorClaim, out uploaderId);
            }

            if (uploaderId == Guid.Empty) return Unauthorized("Invalid identity.");

            var attachment = new TriageAttachment
            {
                CloudinaryPublicId = uploadResult.PublicId,
                UploaderId = uploaderId
            };
            _context.TriageAttachments.Add(attachment);
            await _context.SaveChangesAsync(cancellationToken);

            return Ok(new { attachmentId = attachment.Id });
        }

        // ────────────────────────────────────────────────────────────────────
        // GET api/triage/{id}/image
        // Returns the signed Cloudinary URL for the triage record's image.
        // Enforces patient ownership and staff authorization.
        // ────────────────────────────────────────────────────────────────────
        [Authorize(Roles = "Patient,Doctor,Staff,Admin")]
        [HttpGet("{id:guid}/image")]
        public async Task<IActionResult> GetImage(Guid id, [FromServices] CloudinaryDotNet.Cloudinary cloudinary)
        {
            var record = await _context.TriageRecords.Include(t => t.Attachment).FirstOrDefaultAsync(t => t.Id == id);
            if (record == null || record.Attachment == null)
                return NotFound();

            if (User?.IsInRole("Patient") == true)
            {
                var patientClaim = User?.FindFirst("patient_id")?.Value;
                if (!Guid.TryParse(patientClaim, out var authPatientId) || record.PatientId != authPatientId)
                    return StatusCode(403, "You do not have permission to view this image.");
            }

            var publicId = record.Attachment.CloudinaryPublicId;

            var transform = new CloudinaryDotNet.Transformation();
            var signedUrl = cloudinary.Api.UrlImgUp.Transform(transform)
                .Action("authenticated")
                .Signed(true)
                .BuildUrl(publicId);

            return Redirect(signedUrl);
        }

        // ────────────────────────────────────────────────────────────────────
        // GET api/triage/{id}
        // Returns a single triage record with its AI plan.
        // Used by both Flutter (patient status) and React (doctor review).
        // ────────────────────────────────────────────────────────────────────
        [Authorize(Roles = "Patient,Doctor,Staff,Admin")]
        [HttpGet("{id:guid}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var record = await _context.TriageRecords
                .Include(t => t.AgentWorkflows).Include(t => t.Attachment)
                .Include(t => t.ReviewHistories)
                .FirstOrDefaultAsync(t => t.Id == id);

            if (record == null)
                return NotFound();

            if (User?.IsInRole("Patient") == true)
            {
                var patientClaim = User?.FindFirst("patient_id")?.Value;
                if (!Guid.TryParse(patientClaim, out var authPatientId) || record.PatientId != authPatientId)
                    return StatusCode(403, "You do not have permission to view this triage record.");
            }

            var agent = LatestAgent(record);
            return Ok(MapToDto(record, agent, _cloudinary));
        }

        // ────────────────────────────────────────────────────────────────────
        // GET api/triage
        // React dashboard / Flutter history: list triage records.
        // Patients only see their own records; staff/doctors see all.
        // ────────────────────────────────────────────────────────────────────
        [Authorize(Roles = "Patient,Doctor,Staff,Admin")]
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var query = _context.TriageRecords.AsNoTracking().Include(t => t.AgentWorkflows).Include(t => t.Attachment).AsQueryable();

            if (User?.IsInRole("Patient") == true)
            {
                var patientClaim = User?.FindFirst("patient_id")?.Value;
                if (!Guid.TryParse(patientClaim, out var authPatientId))
                    return StatusCode(403, "Authenticated patient identity is missing or invalid.");

                query = query.Where(t => t.PatientId == authPatientId);
            }

            var records = await query
                .OrderByDescending(t => t.CreatedAt)
                .ToListAsync();

            var response = records.Select(r =>
            {
                var agent = LatestAgent(r);
                return MapToDto(r, agent, _cloudinary);
            });

            return Ok(response);
        }

        // Separate staff endpoints preserve the existing mobile list response contract.
        [Authorize(Roles = "Doctor")]
        [HttpGet("review-queue")]
        public async Task<IActionResult> ReviewQueue([FromQuery] TriageQueueQuery filter)
        {
            var access = CheckStaffAccess();
            if (access != null) return access;
            var query = _context.TriageRecords.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(filter.Search))
            {
                var search = filter.Search.Trim();
                query = query.Where(t => t.Patient.FullName.Contains(search) || t.Symptoms.Contains(search));
            }
            if (filter.Status != null) query = query.Where(t => t.TriageStatus == filter.Status);
            if (filter.Severity != null) query = query.Where(t => t.SeverityLevel == filter.Severity);
            var total = await query.CountAsync();
            var sorted = filter.Sort switch
            {
                "oldest" => query.OrderBy(t => t.CreatedAt),
                "urgency" => query.OrderBy(t => t.SeverityLevel == "Critical" ? 0 :
                    t.SeverityLevel == "High" ? 1 : t.SeverityLevel == "Medium" ? 2 : 3).ThenBy(t => t.CreatedAt),
                _ => query.OrderByDescending(t => t.CreatedAt)
            };
            var records = await sorted.ThenBy(t => t.Id)
                .Skip((filter.Page - 1) * filter.PageSize).Take(filter.PageSize)
                .Include(t => t.Patient).Include(t => t.AgentWorkflows).Include(t => t.Attachment).ToListAsync();
            return Ok(new { items = records.Select(r => MapToDto(r, LatestAgent(r), _cloudinary)), total, filter.Page, filter.PageSize });
        }

        [Authorize(Roles = "Doctor")]
        [HttpGet("review-queue/{id:guid}")]
        public async Task<IActionResult> ReviewDetails(Guid id)
        {
            var access = CheckStaffAccess();
            if (access != null) return access;
            var record = await _context.TriageRecords.AsNoTracking().Include(t => t.Patient)
                .Include(t => t.AgentWorkflows).Include(t => t.Attachment).Include(t => t.ReviewHistories).FirstOrDefaultAsync(t => t.Id == id);
            return record == null ? NotFound() : Ok(MapToDto(record, LatestAgent(record), _cloudinary));
        }

        [Authorize(Roles = "Doctor")]
        [HttpPatch("{id:guid}/review")]
        public async Task<IActionResult> Review(Guid id, [FromBody] ReviewTriageDto dto)
        {
            var access = CheckStaffAccess();
            if (access != null) return access;
            if (!Guid.TryParse(User?.FindFirst("doctor_id")?.Value, out var doctorId) ||
                !await _context.Doctors.AnyAsync(d => d.Id == doctorId && d.IsActive))
                return StatusCode(403, "An active doctor profile is required to review cases.");
            if (!new[] { "Approved", "Rejected", "RevisionRequested" }.Contains(dto.Decision))
                return BadRequest("Choose Approved, Rejected or RevisionRequested.");
            if (dto.ExpectedUpdatedAt == null) return BadRequest("The case version is required.");
            if (dto.DoctorNotes?.Length > 2000) return BadRequest("Notes must be at most 2000 characters.");
            if (dto.Decision != "Approved" && string.IsNullOrWhiteSpace(dto.DoctorNotes))
                return BadRequest("Provide a reason for rejection or revision.");

            await using var transaction = await _context.Database.BeginTransactionAsync(System.Data.IsolationLevel.Serializable);

            try
            {
                var record = await _context.TriageRecords.Include(t => t.Patient)
                    .Include(t => t.AgentWorkflows).Include(t => t.Attachment).FirstOrDefaultAsync(t => t.Id == id);
                if (record == null) return NotFound();
                var agent = LatestAgent(record);
                var conflict = TriageReviewRules.Check(record, agent, dto.ExpectedUpdatedAt);
                if (conflict != null) return Conflict(conflict);

                record.TriageStatus = dto.Decision;
                record.DoctorNotes = dto.DoctorNotes?.Trim();
                record.AssignedDoctorId = doctorId;
                record.UpdatedAt = DateTime.UtcNow;
                if (agent != null)
                {
                    agent.ApprovalStatus = dto.Decision;
                    agent.UpdatedAt = record.UpdatedAt;
                }

                var history = new TriageReviewHistory
                {
                    TriageRecordId = record.Id,
                    AssignedDoctorId = doctorId,
                    Action = dto.Decision,
                    Notes = dto.DoctorNotes?.Trim(),
                    SymptomsAtReview = record.Symptoms,
                    AgentWorkflowStateId = agent?.Id
                };
                _context.TriageReviewHistories.Add(history);

                if (record.TentativeAppointmentId.HasValue)
                {
                    var appointmentService = HttpContext.RequestServices.GetRequiredService<AppointmentService>();
                    if (dto.Decision == "Approved")
                    {
                        await appointmentService.ApproveAsync(record.TentativeAppointmentId.Value, doctorId);
                        var appt = await appointmentService.ConfirmAsync(record.TentativeAppointmentId.Value);
                        if (appt != null)
                        {
                            // Integrate appointment notification through D's agreed contract if available.
                            // Currently unsupported, so record it as pending/unsupported.
                            var notifState = new AgentWorkflowState
                            {
                                TriageRecordId = record.Id,
                                AgentName = "NotificationAgent",
                                AgentStatus = "Unsupported",
                                ErrorMessage = "Pending dependency: Component D NotificationService does not yet support appointment notifications.",
                                StartedAt = DateTime.UtcNow,
                                CompletedAt = DateTime.UtcNow
                            };
                            _context.AgentWorkflows.Add(notifState);
                        }
                        else
                        {
                            // Authorized recovery path: if confirmation fails (e.g. not found), we can still approve the triage
                            // but we mark the appointment as failed.
                            var errorState = new AgentWorkflowState
                            {
                                TriageRecordId = record.Id,
                                AgentName = "AppointmentAgent",
                                AgentStatus = "Failed",
                                ErrorMessage = "Execution failure: The tentative appointment could not be confirmed.",
                                StartedAt = DateTime.UtcNow,
                                CompletedAt = DateTime.UtcNow
                            };
                            _context.AgentWorkflows.Add(errorState);
                            record.TentativeAppointmentId = null;
                        }
                    }
                    else if (dto.Decision == "Rejected" || dto.Decision == "RevisionRequested")
                    {
                        await appointmentService.CancelAsync(record.TentativeAppointmentId.Value);
                        // Release tentative booking but preserve audit history (don't clear ID? Prompt: "Rejection/revision must release the tentative booking and preserve its audit history.")
                        // If we preserve it, maybe don't set TentativeAppointmentId to null, or do we?
                        // "preserve its audit history" could mean keeping the appointment record in the database as 'Cancelled'.
                        // We can set record.TentativeAppointmentId = null so it's not shown as active, but the appointment record remains.
                        record.TentativeAppointmentId = null;
                    }
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();

                // Re-fetch appointment if needed or just let MapToDto handle it
                return Ok(MapToDto(record, agent, _cloudinary));
            }
            catch (DbUpdateConcurrencyException)
            {
                await transaction.RollbackAsync();
                return Conflict("Another reviewer changed this case. Refresh before continuing.");
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                throw;
            }
        }

        [Authorize(Roles = "Patient")]
        [HttpPost("{id:guid}/revise")]
        public async Task<IActionResult> Revise(Guid id, [FromBody] PatientRevisionDto dto, CancellationToken cancellationToken = default)
        {
            var patientClaim = User?.FindFirst("patient_id")?.Value;
            if (!Guid.TryParse(patientClaim, out var authPatientId))
                return StatusCode(403, "Authenticated patient identity is missing or invalid.");

            var record = await _context.TriageRecords
                .Include(t => t.AgentWorkflows).Include(t => t.Attachment)
                .FirstOrDefaultAsync(t => t.Id == id);
            
            if (record == null) return NotFound();
            
            if (record.PatientId != authPatientId)
                return StatusCode(403, "You can only revise your own triage records.");

            if (record.TriageStatus != "RevisionRequested")
                return BadRequest("This record is not currently requesting a revision.");

            if (record.UpdatedAt != dto.ExpectedUpdatedAt)
                return Conflict("This case has changed. Please refresh.");

            record.Symptoms = dto.UpdatedSymptoms.Trim();
            record.TriageStatus = "ReassessmentInProgress";
            record.UpdatedAt = DateTime.UtcNow;

            // Trigger reassessment - persist state first
            var agentState = PlanningAgentService.CreateRunningState(record, null);
            _context.AgentWorkflows.Add(agentState);
            
            try { await _context.SaveChangesAsync(CancellationToken.None); }
            catch (DbUpdateConcurrencyException)
            {
                return Conflict("Another update occurred. Please refresh.");
            }

            await _planningAgent.RunAsync(record, agentState, cancellationToken);
            
            var plan = agentState.AgentStatus == "Completed" ? TriageReviewRules.ReadPlan(agentState.OutputPayload) : null;
            record.TriageStatus = plan == null ? "AssessmentFailed" : "InReview";
            record.SeverityLevel = plan?.UrgencyLevel ?? record.SeverityLevel;
            record.UpdatedAt = DateTime.UtcNow;

            if (plan != null)
            {
                await TriageOrchestrationHelper.ExecuteDownstreamActionsAsync(
                    record, plan, _context, _safetyAgent, _appointmentAgent);
            }

            await _context.SaveChangesAsync(CancellationToken.None);

            return Ok(MapToDto(record, agentState, _cloudinary));
        }

        [Authorize(Roles = "Patient,Doctor,Admin")]
        [HttpPost("{id:guid}/retry")]
        public async Task<IActionResult> Retry(Guid id, CancellationToken cancellationToken = default)
        {
            var record = await _context.TriageRecords
                .Include(t => t.AgentWorkflows).Include(t => t.Attachment)
                .FirstOrDefaultAsync(t => t.Id == id);
            
            if (record == null) return NotFound();
            
            if (User?.IsInRole("Patient") == true)
            {
                var patientClaim = User?.FindFirst("patient_id")?.Value;
                if (!Guid.TryParse(patientClaim, out var authPatientId) || record.PatientId != authPatientId)
                    return StatusCode(403, "You can only retry your own triage records.");
            }

            if (record.TriageStatus != "AssessmentFailed")
                return BadRequest("Only failed assessments can be retried.");

            record.TriageStatus = "ReassessmentInProgress";
            record.UpdatedAt = DateTime.UtcNow;

            var agentState = PlanningAgentService.CreateRunningState(record, null);
            _context.AgentWorkflows.Add(agentState);
            
            try { await _context.SaveChangesAsync(CancellationToken.None); }
            catch (DbUpdateConcurrencyException) { return Conflict("Another update occurred. Please refresh."); }

            await _planningAgent.RunAsync(record, agentState, cancellationToken);
            
            var plan = agentState.AgentStatus == "Completed" ? TriageReviewRules.ReadPlan(agentState.OutputPayload) : null;
            record.TriageStatus = plan == null ? "AssessmentFailed" : "InReview";
            record.SeverityLevel = plan?.UrgencyLevel ?? record.SeverityLevel;
            record.UpdatedAt = DateTime.UtcNow;

            if (plan != null)
            {
                await TriageOrchestrationHelper.ExecuteDownstreamActionsAsync(
                    record, plan, _context, _safetyAgent, _appointmentAgent);
            }

            await _context.SaveChangesAsync(CancellationToken.None);

            return Ok(MapToDto(record, agentState, _cloudinary));
        }

        private IActionResult? CheckStaffAccess()
        {
            // Fail closed until Component A installs its authentication middleware.
            if (User?.Identity?.IsAuthenticated != true) return Unauthorized("Staff sign-in is required.");
            return (User?.IsInRole("Doctor") == true) ? null : StatusCode(403, "Doctor access is required.");
        }

        private static AgentWorkflowState? LatestAgent(TriageRecord record) => record.AgentWorkflows
            .Where(a => a.AgentName == "PlanningAgent")
            .OrderByDescending(a => a.CreatedAt).ThenByDescending(a => a.Id).FirstOrDefault();

        // ── Helper ───────────────────────────────────────────────────────────
        [Authorize(Roles = "Patient")]
        [HttpPost("{id:guid}/book-slot")]
        public async Task<IActionResult> BookSlot(Guid id, [FromBody] AppointmentDto slotRequest)
        {
            var record = await _context.TriageRecords.Include(t => t.AgentWorkflows).FirstOrDefaultAsync(t => t.Id == id);
            if (record == null) return NotFound();

            var patientClaim = User?.FindFirst("patient_id")?.Value;
            if (!Guid.TryParse(patientClaim, out var authPatientId) || record.PatientId != authPatientId)
                return StatusCode(403, "Unauthorized.");

            if (!record.AssignedDoctorId.HasValue)
                return BadRequest("No doctor assigned to this triage record.");

            var agentState = record.AgentWorkflows.OrderByDescending(w => w.CreatedAt).FirstOrDefault(w => w.AgentName == "AppointmentAgent");
            if (agentState != null)
            {
                var agentResponse = await _appointmentAgent.FindAndBookAsync(
                    record.AssignedDoctorId.Value, record.PatientId, slotRequest.AppointmentDate, slotRequest.StartTime, slotRequest.EndTime);
                
                if (agentResponse.Status == CareFlowAI.Orchestrator.Models.AppointmentActionStatus.Success && agentResponse.AppointmentId.HasValue)
                {
                    record.TentativeAppointmentId = agentResponse.AppointmentId.Value;
                    agentState.AgentStatus = "Completed";
                    agentState.OutputPayload = agentResponse.Message;
                    agentState.CompletedAt = DateTime.UtcNow;
                    await _context.SaveChangesAsync();
                    return Ok(MapToDto(record, agentState, _cloudinary));
                }
                return BadRequest(agentResponse.Message);
            }
            return BadRequest("Agent state not found.");
        }

        private static TriageResponseDto MapToDto(TriageRecord record, AgentWorkflowState? agent, CloudinaryDotNet.Cloudinary? cloudinary = null)
        {
            string? imageUrl = null;
            if (record.Attachment != null && cloudinary != null)
            {
                try
                {
                    var publicId = record.Attachment.CloudinaryPublicId;
                    var transform = new CloudinaryDotNet.Transformation();
                    imageUrl = cloudinary.Api.UrlImgUp.Transform(transform)
                        .Action("authenticated")
                        .Signed(true)
                        .BuildUrl(publicId);
                } catch { /* fallback */ }
            }

            var apptWorkflow = record.AgentWorkflows?.Where(a => a.AgentName == "AppointmentAgent").OrderByDescending(a => a.CreatedAt).FirstOrDefault();
            var safetyWorkflow = record.AgentWorkflows?.Where(a => a.AgentName == "SafetyAgent").OrderByDescending(a => a.CreatedAt).FirstOrDefault();
            var notifWorkflow = record.AgentWorkflows?.Where(a => a.AgentName == "NotificationAgent").OrderByDescending(a => a.CreatedAt).FirstOrDefault();

            string schedulingOutcome = "Pending";
            AppointmentDto? apptDetails = null;
            List<AvailableSlotDto>? availableSlots = null;
            if (apptWorkflow != null)
            {
                if (apptWorkflow.AgentStatus == "Completed" && !string.IsNullOrWhiteSpace(apptWorkflow.OutputPayload))
                {
                    schedulingOutcome = "Booked";
                    try { apptDetails = System.Text.Json.JsonSerializer.Deserialize<AppointmentDto>(apptWorkflow.OutputPayload, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true }); } catch { }
                }
                else if (apptWorkflow.AgentStatus == "ActionRequired" && !string.IsNullOrWhiteSpace(apptWorkflow.OutputPayload))
                {
                    schedulingOutcome = "ActionRequired";
                    try { availableSlots = System.Text.Json.JsonSerializer.Deserialize<List<AvailableSlotDto>>(apptWorkflow.OutputPayload, new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true }); } catch { }
                }
                else
                {
                    schedulingOutcome = apptWorkflow.ErrorMessage ?? "Failed";
                }
            }

            string? safetyVerdict = null;
            string? safetySummary = null;
            if (safetyWorkflow != null && !string.IsNullOrWhiteSpace(safetyWorkflow.OutputPayload))
            {
                try 
                {
                    var safetyDoc = System.Text.Json.JsonDocument.Parse(safetyWorkflow.OutputPayload);
                    if (safetyDoc.RootElement.TryGetProperty("Verdict", out var v)) safetyVerdict = v.GetString();
                    if (safetyDoc.RootElement.TryGetProperty("Summary", out var s)) safetySummary = s.GetString();
                } catch {}
            }

            string? notifOutcome = null;
            if (notifWorkflow != null)
            {
                notifOutcome = notifWorkflow.ErrorMessage ?? notifWorkflow.AgentStatus;
            }

            return new TriageResponseDto
            {
                Id               = record.Id,
                PatientId        = record.PatientId,
                PatientName      = record.Patient?.FullName,
                Symptoms         = record.Symptoms,
                ImageUrl         = imageUrl,
                SeverityLevel    = record.SeverityLevel,
                TriageStatus     = record.TriageStatus,
                DoctorNotes      = record.DoctorNotes,
                AssignedDoctorId = record.AssignedDoctorId,
                CreatedAt        = record.CreatedAt,
                UpdatedAt        = record.UpdatedAt,
                AiPlan           = TriageReviewRules.ReadPlan(agent?.OutputPayload) == null ? null : agent?.OutputPayload,
                AiAgentStatus    = agent?.AgentStatus,
                ApprovalStatus   = agent?.ApprovalStatus,
                AnalysisMethod   = TriageReviewRules.ReadPlan(agent?.OutputPayload)?.AnalysisMethod,
                PlanningExecution = TriageReviewRules.ReadExecution(agent?.OutputPayload),
                TentativeAppointmentId = record.TentativeAppointmentId,
                SchedulingOutcome = schedulingOutcome,
                AppointmentDetails = apptDetails,
                AvailableSlots = availableSlots,
                SafetyVerdict = safetyVerdict,
                SafetySummary = safetySummary,
                NotificationOutcome = notifOutcome,
                ReviewHistories  = record.ReviewHistories?.OrderByDescending(h => h.CreatedAt).Select(h => new TriageReviewHistoryDto
                {
                    Id = h.Id,
                    ReviewerId = h.AssignedDoctorId,
                    LinkedAttemptId = h.AgentWorkflowStateId,
                    Action = h.Action,
                    Notes = h.Notes,
                    SymptomsAtReview = h.SymptomsAtReview,
                    PreviousPlan = h.AgentWorkflowState?.OutputPayload,
                    CreatedAt = h.CreatedAt
                }).ToList() ?? new List<TriageReviewHistoryDto>()
            };
        }
    }
}
